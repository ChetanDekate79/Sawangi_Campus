import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Bar_graph from "./bar_graph";
import { FaChartBar, FaFileCsv, FaFileAlt, FaSun } from 'react-icons/fa';
import Report_wardha from "./report_wardha";
import './side_bar.css';
import LineChart_csv from './GraphComponent2'
import BoxWithButton from './BoxWithButton';

const Sidebar_wardha = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate a loading delay
    setTimeout(() => {
      setIsLoading(false);
    }, 2000); // Set the duration of the loading delay in milliseconds
  }, []);

  return (
    <Router>
      <div className="sidebar">
        <ul>
          <li>
            <Link to="/">
              <FaChartBar size={24} />
            </Link>
          </li>
          <li>
            <Link to="/graph_csv">
              <FaFileCsv size={24} />
            </Link>
          </li>
          <li>
            <Link to="/report_wardha">
              <FaFileAlt size={24} />
            </Link>
          </li>
          <li>
            <Link to="/solar">
              <FaSun size={24} />
            </Link>
          </li>
        </ul>

        <div className="content">
          {isLoading ? (
            <div className="loading-bar">
              <div className="spinner"></div>
              Loading...
            </div>
          ) : (
            <Routes>
              <Route path="/" element={<Bar_graph />} />
              <Route path="/graph_csv" element={<LineChart_csv />} />
              <Route path="/report_wardha" element={<Report_wardha />} />
              <Route path="/solar" element={<BoxWithButton />} />
            </Routes>
          )}
        </div>
      </div>
    </Router>
  );
};

export default Sidebar_wardha;
