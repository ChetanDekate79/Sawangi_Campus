import React, { useState, useEffect, useRef } from 'react';
import { create as am4coreCreate, useTheme as am4coreUseTheme } from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import * as am4core from "@amcharts/amcharts4/core";

import am4themes_animated from '@amcharts/amcharts4/themes/animated';

am4core.useTheme(am4themes_animated);

const LineChart_csv = () => {
  const chartRef = useRef(null);
  const [data, setData] = useState([]);
  const [selectedColumnsY, setSelectedColumnsY] = useState([]);
  const [selectedColumnsYName, setSelectedColumnsYName] = useState([]);
  const [selectedColumnX, setSelectedColumnX] = useState(0); // Column index for x-axis
  const [selectedColumnY, setSelectedColumnY] = useState([]); // Default column indices for y-axis
  const [SelectedDeviceName2, setSelectedDeviceName] = useState("");
  const [SelectedDevice2Name, setSelectedDevice2Name] = useState("");

  const [SelectedHostName2, setSelectedHostName] = useState("");
  const [selectedHost, setSelectedHost] = useState("");
  const [isLoadingData, setIsLoadingData] = useState(true); // New state variable for loading screen
  const [selectedDevice, setSelectedDevice] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));

  const handleColumnYChange = (event) => {
    const deviceName = event.target.options[event.target.selectedIndex].text;
    const selectedOptions = Array.from(event.target.selectedOptions);
    const selectedValues = selectedOptions.map((option) => option.value);
    const selectedNames = selectedOptions.map((option) => option.getAttribute('name'));
    setSelectedDeviceName(deviceName);
    setSelectedColumnsY(selectedValues);
    setSelectedColumnsYName(selectedNames);
  };
  console.log("SelectedDeviceName2 for kw",SelectedDeviceName2)
  const deviceNames = SelectedDeviceName2.split(',');

  // Assign values to separate variables
  const variable1 = deviceNames[0];
  const variable2 = deviceNames[1];
  const variable3 = deviceNames[2];
  const variable4 = deviceNames[3];


  console.log(variable2)
  // ...
  
  

  const onHostChange = (event) => {
    const HostName = event.target.options[event.target.selectedIndex].text;
    const host = event.target.value;
    setSelectedHostName(HostName);
    setSelectedHost(host);

    // Update the device options based on the selected host
    if (host === 'J9') {
      setSelectedDevice('');
    } else if (host === 'J10') {
      setSelectedDevice('');
    } else if (host === 'J4') {
      setSelectedDevice('');
    } else if (host === 'J5') {
      setSelectedDevice('');
    } else if (host === 'J6') {
      setSelectedDevice('');
    } else if (host === 'J7') {
      setSelectedDevice('');
    } else if (host === 'J8') {
      setSelectedDevice('');
    } else if (host === 'AV11') {
      setSelectedDevice('');
    } else if (host === 'JB8') {
      setSelectedDevice('');
    } else if (host === 'AV7') {
      setSelectedDevice('');
    } else if (host === 'JB1') {
      setSelectedDevice('');
    } else if (host === 'JB2') {
      setSelectedDevice('');
    } else if (host === 'JB3') {
      setSelectedDevice('');
    } else if (host === 'JB4') {
      setSelectedDevice('');
    } else if (host === 'JB5') {
      setSelectedDevice('');
    } else if (host === 'JB6') {
      setSelectedDevice('');
    } else if (host === 'JBM') {
      setSelectedDevice('');
    } else if (host === 'AV1') {
      setSelectedDevice('');
    } else if (host === 'AV10') {
      setSelectedDevice('');
    } else if (host === 'AV15') {
      setSelectedDevice('');
    } else if (host === 'AV16') {
      setSelectedDevice('');
    } else if (host === 'AV17') {
      setSelectedDevice('');
    } else if (host === 'AV18') {
      setSelectedDevice('');
    } else if (host === 'AV2') {
      setSelectedDevice('');
    } else if (host === 'AV3') {
      setSelectedDevice('');
    } else if (host === 'AV4') {
      setSelectedDevice('');
    } else if (host === 'AV5') {
      setSelectedDevice('');
    } else if (host === 'AV6') {
      setSelectedDevice('');
    } else if (host === 'AV8') {
      setSelectedDevice('');
    } else if (host === 'AV9') {
      setSelectedDevice('');
    } else {
      setSelectedDevice('23');
    }
  };

  const onDeviceChange = (event) => {
    const deviceName = event.target.options[event.target.selectedIndex].text;
    const device = event.target.value;
    setSelectedDevice2Name(deviceName);
    setSelectedDevice(device);
  };
  const handleColumnXChange = (event) => {
    setSelectedColumnX(parseInt(event.target.value));
  };


  
  const handleHostChange = (event) => {
    setSelectedHost(event.target.value);
  };

  const handleDeviceChange = (event) => {
    setSelectedDevice(event.target.value);
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };

  

  const fetchData = async () => {
    try {
      setIsLoadingData(true); // Set isLoadingData to true before making the API call
  
      const formattedDate = selectedDate.split("-").reverse().join("-");
      const response = await fetch(`http://127.0.0.1:8001/api/csv-data/${selectedHost}/${formattedDate}/${selectedDevice}`);
      const jsonData = await response.json();
      setData(jsonData);
      setIsLoadingData(false); // Set isLoadingData to false after data is fetched
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoadingData(false); // Set isLoadingData to false in case of an error
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedHost, selectedDevice, selectedDate]);
  

  
  
  useEffect(() => {
    if (data.length > 0) {
      const chart = am4core.create("chartdiv_g", am4charts.XYChart);
  
      // Enable drag-to-zoom
      chart.cursor = new am4charts.XYCursor();
      chart.cursor.behavior = 'zoomX'; // Enable zooming horizontally

      const updateChartData = () => {
  const updatedData = data.map((row) => {
    const dateTimeString = row[selectedColumnX];
    const [datePart, timePart] = dateTimeString.split(' ');

    const [hours, minutes] = timePart.split(':');
    const formattedTime = `${hours}:${minutes}`;

    const columnIndices = selectedColumnsY[0].split(',').map((column) => parseInt(column));

    const yValues = columnIndices.map((index) => parseFloat(row[index]));
    console.log("columnIndices", columnIndices)

    const hasNonNullValue = yValues.some((value) => value !== null && !isNaN(value));

    if (hasNonNullValue) {
      const nonNullValues = yValues.map((value) => (value !== null && !isNaN(value)) ? [value] : null);
      console.log("the first ", nonNullValues[0]);

      // Print the elements inside columnIndices
      const elements = columnIndices.map((index) => row[index]);
      console.log("Elements inside columnIndices:", elements);

      return {
        c: columnIndices,
        x: formattedTime,
        y: nonNullValues[0],
        y1: nonNullValues[1],
        y2: nonNullValues[2],
        y3: nonNullValues[3],
      };
    }

    return null;
  }).filter((dataPoint) => dataPoint !== null);

  chart.data = updatedData;
};

      
        
      updateChartData();
      console.log("c",'c')
      const categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = 'x';
      // categoryAxis.title.text = 'X-axis';
  
      const valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

      // valueAxis.title.text = 'Y-axis';
  
const series = chart.series.push(new am4charts.LineSeries());
series.dataFields.categoryX = 'x';
series.dataFields.valueY = 'y';
series.strokeWidth = 2;
series.minBulletDistance = 30; // Increase the value to increase the distance
series.tooltipText = "{y}";
series.fill = am4core.color("#28a745");
series.stroke = am4core.color("#28a745");
series.name = variable1;
  // Set the legend name for the series
      
      

      const series1 = chart.series.push(new am4charts.LineSeries());
      series1.strokeWidth = 2;
      series1.minBulletDistance = 10;
      series1.dataFields.categoryX = 'x';
      series1.dataFields.valueY = 'y1';
      series1.tooltipText = "{y1}";
      series1.fill = am4core.color("#ef4040");
      series1.stroke = am4core.color("#ef4040");
      series1.name = variable2;
      

      const series2 = chart.series.push(new am4charts.LineSeries());
      series2.strokeWidth = 2;
      series2.minBulletDistance = 10;
      series2.dataFields.categoryX = 'x';
      series2.dataFields.valueY = 'y2';
      series2.tooltipText = "{y2}";
      series2.fill = am4core.color("#ffc107");
      series2.stroke = am4core.color("#ffc107");
      series2.name=variable3;

      const series3 = chart.series.push(new am4charts.LineSeries());
      series3.strokeWidth = 2;
      series3.minBulletDistance = 10;
      series3.dataFields.categoryX = 'x';
      series3.dataFields.valueY = 'y3';
      series3.tooltipText = "{y3}";
      series3.fill = am4core.color("#008FFB");
      series3.stroke = am4core.color("#008FFB");
      series3.name = variable4;


      const title = chart.titles.create();
      title.text = SelectedHostName2+" / "+SelectedDevice2Name+ " - "+ selectedDate;
      title.fontSize = 20;
      title.marginBottom = 20;


  
      chart.legend = new am4charts.Legend();
      chart.legend.useDefaultMarker = true;
      chart.legend.position = "bottom";  
      return () => {
        chart.dispose();
      };
    }
  }, [data,selectedColumnX, selectedColumnsY,selectedDate]);
  
  
  

  return (
    <div>
      <div style={{ display: "flex",  marginBottom: "10px" }}>
      <div style={{ marginBottom: "10px" }}>
  <label htmlFor="columnSelectY" style={{ fontWeight: "bold", display: "block" }}>
    Parameters:
  </label>
  <select
    id="columnSelectY"
    value={selectedColumnsY}
    onChange={handleColumnYChange}
    style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      marginRight: "15px",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
    }}
  >
          <option value="">Select Parameters</option>
          <option value={['4', '5', '6', '7']}>kW_Total, R-phase, Y-phase, B-phase</option>
          <option value={['8', '9', '10', '11']}>VAR_Total, R-phase, Y-phase, B-phase</option>
    <option value={['12', '13', '14', '15']}>PF_Ave, R-phase, Y-phase, B-phase</option>
    <option value={['16', '17', '18', '19']}>VA_total, R-phase, Y-phase, B-phase</option>
    <option value={['20', '21', '22', '23']}>VLL_average, R-phase, Y-phase, B-phase</option>
    <option value={['24', '25', '26', '27']}>VLN_average,  R-phase, Y-phase, B-phase</option>
    <option value={['28', '29', '30', '31']}>Current_Average, R-phase, Y-phase, B-phase</option>
    <option value={['46', '47', '48']}>Voltage-R-Harm, Voltage-Y-Harm, Voltage-B-Harm</option>
    <option value={['49', '50', '51']}>Current-R-Harm, Current-Y-Harm, Current-B-Harm</option>
    
     <option value="32">Frequency</option>
     <option value="33">kWh_Received</option>
     <option value="34">VAh_Received</option>
     <option value="35">VARh_Ind._Received</option>
     <option value="36">VARh_Cap._Received</option>
     <option value="37">kWh_Delivered</option>
     <option value="38">VAh_Delivered</option>
     <option value="39">VARh_Ind._Delivered</option>
     <option value="40">VARh_Cap._Delivered</option>
     <option value="41">Reserved</option>
     <option value="42">Reserved</option>
     <option value="43">Reserved</option>
     <option value="44">Reserved</option>
     <option value="45">Reserved</option>

     <option value={['52', '53', '54']}>kWh received Phase-R, Phase-Y, Phase-B</option>
     <option value={['55', '56', '57']}>kVAh received Phase-R, Phase-Y, Phase-B</option>
     <option value={['58', '59', '60']}>kVArh inductive received Phase-R, Phase-Y, Phase-B</option>
     <option value={['61', '62', '63']}>kVArh capacitive received Phase-R, Phase-Y, Phase-B</option>
     <option value={['64', '65', '66']}>PF average received Phase-R, Phase-Y, Phase-B</option>
     <option value={['67', '68', '69']}>A average received Phase-R, Phase-Y, Phase-B</option>
     <option value={['70', '71', '72']}>kWh delivered Phase-R, Phase-Y, Phase-B</option>
     <option value={['73', '74', '75']}>kVAh delivered Phase-R, Phase-Y, Phase-B</option>
     <option value={['76', '77', '78']}>kVArh inductive delivered Phase-R, Phase-Y, Phase-B</option>
     <option value={['79', '80', '81']}>kVArh capacitive delivered Phase-R, Phase-Y, Phase-B</option>
  </select>
</div>
<div style={{ marginBottom: "10px" }}>
  <label htmlFor="select_host" style={{ fontWeight: "bold", display: "block" }}>
    Host:
  </label>
  <select
    id="select_host"
    value={selectedHost}
    onChange={onHostChange}
    style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      fontFamily: "Arial, sans-serif",
      marginRight: "15px",
      fontSize: "14px",
      minWidth: "200px", // Adjust the width as needed
    }}
  >
     <option value="">Select Host</option>
    <option value="AV10">AVBRH Electrical Room</option>
      <option value="AV18">Cancer Hospital GF Panel Room</option>
      <option value="AV4">Central Kitchen</option>
      <option value="AV16">Chiller Room</option>
      <option value="AV6">CVTS Building</option>

      <option value="J7">Durga</option>
      <option value="JB2">Ganesh</option>
      <option value="AV17">Guest House Feeder Panel</option>
      <option value="J5">Gayatri</option>

      <option value="J10">Jijau</option>
      <option value="AV7">Main Panel Room(Boy Hostel)</option>   
      <option value="J4">Main Incomer Panel Health Club (Shalinata)</option>
      <option value="AV15">Main Incomer Panel AVBRH(500KVA Incomer Panel Room)</option>      
      <option value="AV11">Main Incomer Panel JNMC(750 KVA Incomer (JNMC) panel room)</option>
      <option value="JBM">Meghdoot apartment</option>

      <option value="AV9">NSB Building</option>
      <option value="AV3">Ortho Panel</option>
      <option value="AV1">OT store</option>


      <option value="JB4">Paramhans</option>
      <option value="J8">Radhikabai & Indira</option>
      <option value="AV5">Raghobaji Hostel</option>

      <option value="JB5">Sai</option>
      <option value="AV12">Saraswati hostel</option>
      <option value="JB8">Saraswati hostel</option>      
      <option value="J6">sharda</option>
      <option value="JB6">Shivaji</option>
      <option value="AV2">SPDC Vodafone Tower</option> 

      <option value="JB1">University Building Panel Room</option>
      <option value="J9">Vaishnavi</option>
      <option value="JB3">Vivekanand</option>
      <option value="AV8">Yashoda Hostel Panel</option>  
        
  </select>
</div>
<div style={{ marginBottom: "10px" }}>
  <label htmlFor="select_device" style={{ fontWeight: "bold", display: "block" }}>
    Device:
  </label>
  <select
    id="select_device"
    value={selectedDevice}
    onChange={onDeviceChange}
    style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      fontFamily: "Arial, sans-serif",
      marginRight: "15px",
      fontSize: "14px",
      minWidth: "200px", // Adjust the width as needed
    }}
  >
        {selectedHost === 'AV11' ? (
          <>
            <option value="">Select</option>
            <option value="31">Auditorium</option>
            <option value="42">Food Court Feeder</option>
            <option value="40">JNMC Dean Office Feeder</option>
            <option value="33">JNMC Lecture Feeder</option>   
            <option value="50">JNMC Solar</option> 
            <option value="49">MET HALL Feeder</option>
            <option value="27">Museum Ac</option>
            <option value="44">Saraswati Hostel</option>
            <option value="29">SPDC+Nursing+University Feeder</option>     
            <option value="43">SPDC</option> 
            <option value="41">STP PLANT (DMIHER)</option>                          
            <option value="23">750KVA JNMC LT Incomer</option>
            <option value="57">315 KVA Transformer JNMC</option>

            
            
            

          </>
           ) : selectedHost === 'JB8' ? (
            <>
              <option value="">Select</option>
              <option value="45">FF Mess Saraswati</option>
              <option value="46">GF Mess Saraswati</option>
              
            </>
        ) : selectedHost === 'AV16' ? (
          <>
            <option value="">Select</option>
            <option value="60">Main HVAC P1</option>
            <option value="61">Main HVAC P2</option>
            <option value="62">NSB Solar</option>
            <option value="63">Secondary Pump</option>
          </>
          ) : selectedHost === 'J8' ? (
            <>
            <option value="">Select</option>
            <option value="62">Indira Hostel Main</option>
            <option value="61">Radhikabai Hostel Main</option>      
            <option value="31">Load Radhikabai AC1</option>
            <option value="32">Load Radhikabai Light + common area</option>
            <option value="33">Load Radhikabai AC2</option>
            <option value="34">Load Indira AC1</option>
            <option value="35">Load Indira Light1 + common area</option>
            <option value="45">Load Indira AC2</option>
            <option value="46">Load Indira Light2 + common area</option>
            <option value="47">Load Radhikabai AC4</option>
            <option value="48">Load Radhikabai Indus Tower</option>
            <option value="49">Load Radhikabai AC3</option>
            <option value="50">Load Indira RO Water Plant</option>
            <option value="21">Solar Indira</option>
            <option value="20">Solar Radhikabai</option>
            
            

            </>
          ) : selectedHost === 'J7' ? (
            <>
              <option value="">Select</option>              
              <option value="59">Durga Borewell</option>
            </>
          ) : selectedHost === 'J6' ? (
            <>
              <option value="">Select</option>
              <option value="22">Load Sharda Light + common area</option>
              <option value="24">Load Sharda AC</option>
              <option value="16">Solar Sharda</option>
              <option value="64">Sharda Hostel Main</option>
            </>
           ) : selectedHost === 'J5' ? (
            <>
              <option value="">Select</option>
              <option value="60">Gayatri Hostel Main </option>
              <option value="25">Load Gayatri AC1</option>
             
            </>
           ) : selectedHost === 'J4' ? (
            <>
              <option value="">Select</option>
              <option value="65">Gym</option>
              <option value="3">Hostel Sharda Light</option>
              <option value="4">Hostel Durga</option>
              <option value="5">Hostel  Sharda AC</option>
              <option value="7">Health Club</option>              
              <option value="9">Hostel Radhikabai</option>
              <option value="10">Hostel Indira</option>
              <option value="11">Hostel Shalinata</option>
              <option value="8">Load Reception</option>
              <option value="36">Load Shalinata AC1</option>
              <option value="37">Load Shalinata Light1 + common area</option>
              <option value="38">Load Shalinata Light2 + common area</option>
              <option value="39">Load Shalinata AC2</option>
              <option value="40">Load Shalinata AC3</option>
              <option value="41">Load Shalinata Light3 + common area</option>
              <option value="42">Load Shalinata AC4</option>
              <option value="43">Load Shalinata Light4 + common area</option>
              <option value="6">PG Guest House & Banglow</option>
              <option value="66">VIP Guest House</option>
              <option value="1">800 KVA Health Club Incomer</option>
              <option value="2">750 KVA Health Club Incomer</option>
              

              
            </>
           ) : selectedHost === 'J9' ? (
            <>
            
              <option value="">Select</option>
              <option value="12">Hostel Gayatri</option>
              <option value="13">Hostel Vaishnavi</option>
              <option value="51">Meghe Height Common Area1</option>
              <option value="52">Meghe Height Common Area2</option>
              <option value="54">Meghe Height Building 1</option>
              <option value="55">Meghe Height Building 2</option>
              <option value="56">Meghe Height Building 3</option>
              <option value="57">Meghe Height Building 4</option>
              <option value="14">Meghe Height</option>            
              <option value="18">Solar Vaishnavi</option>
              
              
            </>
            ) : selectedHost === 'J10' ? (
              <>
               <option value="">Select</option>
               <option value="15">Hostel Jijau</option>
                <option value="58">Jijau AC2</option>
                <option value="63">Jijau Hostel Main</option>
                <option value="29">Load Jijau AC</option>
                <option value="30">Load Jijau Light + common area</option>
                
               
                
                
              </>
        ) : selectedHost === 'AV7' ? (
          <>
            <option value="">Select</option>
            
            <option value="4">Ganesh + Shivaji</option>
            <option value="10">Sai Panel</option>
            <option value="11">STP</option>
            <option value="7">Paramhans Panel</option>
            <option value="8">Vivekanand AC Panel</option>
            <option value="9">Vivekanand Light Panel</option>          
            <option value="1">315 Incomer (Boys hostel Feeder)</option>
            <option value="2">200 Incomer</option>
          </>
          ) : selectedHost === 'JB1' ? (
            <>
              <option value="">Select</option>
              <option value="54">Nursing Main</option>
              <option value="53">Solar Nursing</option>
              <option value="56">Solar University</option>                       
              <option value="55">University Main</option>
              </>
          ) : selectedHost === 'JB2' ? (
            <>
              <option value="">Select</option>
              <option value="5">Ganesh</option>
              <option value="20">Solar Ganesh</option>
              <option value="21">Load Ganesh AC</option>
              <option value="22">Load Ganesh Light + common area</option>
            </>
            ) : selectedHost === 'JB3' ? (
              <>
                <option value="">Select</option>
                <option value="18">Solar Vivekanand</option>
                <option value="30">Load Vivekanand AC</option>
                <option value="32">Load Vivekanand Airtel</option>
                <option value="34">Load Vivekanand Light + Airtel + common area</option>
              </>
              ) : selectedHost === 'JB4' ? (
                <>
                  <option value="">Select</option>
                  <option value="51">Paramhans Hostel Main</option>
                  <option value="17">Solar Paramhans</option>                
                 
                </>
                ) : selectedHost === 'JB5' ? (
                  <>
                    <option value="">Select</option>
                    <option value="19">Solar Sai</option>
                    <option value="35">Load Sai Light + common area</option>
                    <option value="36">Load Sai Mess</option>
                  </>
                  ) : selectedHost === 'JB6' ? (
                    <>
                      <option value="">Select</option>
                      <option value="6">Shivaji</option>
                      <option value="16">Solar Shivaji</option>
                      <option value="24">Load Ganesh Mess</option>
                      <option value="25">Load Shivaji AC</option>
                      <option value="26">Load Shivaji Light + common area</option>
                    </>
                    ) : selectedHost === 'JBM' ? (
                      <>
                        <option value="">Select</option>                        
                        <option value="12">Meghdhoot Block 1</option>
                        <option value="13">Meghdhoot Block 2</option>
                        <option value="14">Meghdhoot Block 3</option>
                        <option value="15">Meghdhoot Block 4 & 5</option>
                        <option value="39">Meghdhoot Pump</option>
                        <option value="37">Load Meghdhoot Block 4</option>
                        <option value="38">Load Meghdhoot Block 5</option>
                        <option value="3">315 Incomer Meghdoot</option>
                        
                      </>
                      ) : selectedHost === 'AV1' ? (
                        <>``
                          <option value="">Select</option>
                          <option value="23">Cotex Pharmacy OT Store FF A Block AVBRH</option>
                        </>
                        ) : selectedHost === 'AV10' ? (
                          <>
                            <option value="">Select</option>
                            <option value="2">A Block & C Block Solar AVBRH</option>
                            <option value="22">Cotex Pharmacy Store GF A Block AVBRH</option>
                          </>
                          ) : selectedHost === 'AV15' ? (
                            <>
                            <option value="">Select</option>
                            <option value="21">A Block 270 KVA Panel Room</option>         
                            <option value="57">Cancer Hospital</option>
                            <option value="19">Cathlab Feeder</option>
                            <option value="55">Critical</option>
                            <option value="20">CT Scan Feeder</option>
                            <option value="7">Fire Pump Feeder</option>
                            <option value="6">Guest House Panel Feeder</option>   
                            <option value="54">NON critical</option>                         
                            <option value="5">Ortho Panel Feeder</option>
                            <option value="8">RNPC Feeder</option>
                            <option value="9">TUCB ATM from 500 kVA TR</option>
                            <option value="4">Yashoda Feeder</option>
                            <option value="3">500 kVA AVBRH LT</option>
                            <option value="18">750 kVA AVBRH LT -Incomer</option>                                                                           
                            <option value="56">800 kVA T1</option> 
                            <option value="53">800 KVA T2</option>
                            </>
                            ) : selectedHost === 'AV16' ? (
                              <>
                                <option value="">Select</option>
                                <option value="60">Main HVAC P1</option>
                                <option value="61">Main HVAC P2</option>
                                <option value="62">NSB Solar</option>
                                <option value="63">Secondary Pump</option>
                              </>
                              ) : selectedHost === 'AV17' ? (
                                <>
                                  <option value="">Select</option>
                                  <option value="42">BSNL Tower</option>
                                  <option value="14">Doctor Qtrs1 (Mahajan Building)</option>
                                  <option value="15">Doctor Qtrs2 (Sune Building)</option>
                                  <option value="16">Guest House Load</option>
                                  <option value="13">Laundry</option>                                  
                                 
                                  
                                </>
                                ) : selectedHost === 'AV18' ? (
                                  <>
                                    <option value="">Select</option>
                                    <option value="68">AHU Basement</option>
                                    <option value="69">AHU Basement(LINAC M/C)</option>
                                    <option value="70">AHU GF Panel</option>
                                    <option value="71">AHU TF</option>
                                    <option value="65">Cancer Hospital Pharmacy</option>
                                    <option value="67">Solar Cancer</option>
                                    

                                  </>
                                  ) : selectedHost === 'AV2' ? (
                                    <>
                                      <option value="">Select</option>
                                      <option value="1">Vodafone Tower</option>
                                    </>
                                      ) : selectedHost === 'AV3' ? (
                                        <>
                                          <option value="">Select</option>
                                          <option value="73">Ortho Panel Room</option>
                                          <option value="72">Solar Ortho</option>                                          
                                          <option value="11">SODAXSO</option>
                                        </>
                                    ) : selectedHost === 'AV4' ? (
                                      <>
                                        <option value="">Select</option>
                                  <option value="17">Central Kitchen</option>
                                  <option value="50">MRI</option>
                                  <option value="51">Oxygen Plant 1</option>
                                  <option value="52">Oxygen Plant 2</option>
                                  <option value="58">Road Side Pharmacy</option>
                                      </>
                                      ) : selectedHost === 'AV5' ? (
                                        <>
                                          <option value="">Select</option>
                                        <option value="47">Raghobaji AC</option>
                                        <option value="43">Raghobaji Main</option>                                        
                                        <option value="48">Raghobaji Light</option>
                                        </>
                                        ) : selectedHost === 'AV6' ? (
                                          <>
                                            <option value="">Select</option>
                                      <option value="24">Mai Optical</option>
                                      <option value="25">PNB ATM</option>
                                          </>
                                          ) : selectedHost === 'AV8' ? (
                                            <>
                                              <option value="">Select</option>
                                        <option value="46">Cotex Pharmacy Store</option>
                                        <option value="66">WHC Store (Yashoda)</option>
                                        <option value="10">Yashoda Solar</option>                                        
                                        <option value="12">Yashoda Hostel Main</option>
                                        <option value="44">Yashoda AC1</option>
                                        <option value="45">Yashoda AC2</option>
                                        
                                            </>
                                            ) : selectedHost === 'AV9' ? (
                                              <>
                                                <option value="">Select</option>
                                          <option value="41">Cotex Pharmacy Store GF NSB AVBRH</option>
                                          <option value="59">Cotex Pharmacy NSB (2F)</option>                                                                        
                                          <option value="74">NSB OT Pharmacy 2F</option>
                                          <option value="40">TUCB ATM (NSB)</option>
                                          
                                          
                                              </>
        ) : (
          
          <option value="">Select Device</option>
        )}
      </select>
</div>

     
<div style={{ marginBottom: "10px" }}>
  <label htmlFor="datePicker" style={{ fontWeight: "bold", display: "block" }}>
    Date:
  </label>
  <input
    type="date"
    id="datePicker"
    value={selectedDate}
    onChange={handleDateChange}
    style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
    }}
  />
</div>

</div>




<div>
    {/* ... */}
    {isLoadingData ? (
      <div>Loading...</div>
    ) : (
      <div id="chartdiv_g" style={{ width: "95%", height: "75vh" }} />
    )}
  </div>    </div>
  );
};

export default LineChart_csv;
