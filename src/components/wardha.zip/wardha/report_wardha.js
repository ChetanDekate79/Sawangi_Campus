import React, { useState, useEffect,useRef } from "react";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import './report_wardha.css'
am4core.useTheme(am4themes_animated);

const Report_wardha = () => {
  const [chartData, setChartData] = useState([]);
  const [selectedHost, setSelectedHost] = useState("");
  const [selectedDevice, setSelectedDevice] = useState("");
  const [SelectedDeviceName2, setSelectedDeviceName] = useState("");
  const [reportUrl, setReportUrl] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const iframeRef = useRef(null);
  
  const [isLoading, setIsLoading] = useState(true); // New state variable for loading status
  let selectedHostname;
  let selectedDevicename;

  if (selectedDevice === "45") {
    selectedDevicename = "Saraswati Hostel LIght Load - 1";
   } else if (selectedDevice === "46") {
    selectedDevicename = "Saraswati Hostel Light Load - 2";
   } else if (selectedDevice === "47") {
    selectedDevicename = "Saraswati Mess - 1";
   } else if (selectedDevice === "48") {
    selectedDevicename = "Saraswati Mess - 2";
   } else if (selectedDevice === "60") {
    selectedDevicename = "Main HVAC P1";
   } else if (selectedDevice === "61") {
    selectedDevicename = "Main HVAC P2";
   } else if (selectedDevice === "62") {
    selectedDevicename = "NSB Solar";
   } else if (selectedDevice === "63") {
    selectedDevicename = "Secondary Pump";
   } else if (selectedDevice === "20") {
    selectedDevicename = "Solar Radhikabai";
   } else if (selectedDevice === "21") {
    selectedDevicename = "Solar Indira";
   } else if (selectedDevice === "31") {
    selectedDevicename = "Load Radhikabai AC1";
   } else if (selectedDevice === "32") {
    selectedDevicename = "Load Radhikabai Light + common area";
   } else if (selectedDevice === "33") {
    selectedDevicename = "Load Radhikabai AC2";
   } else if (selectedDevice === "34") {
    selectedDevicename = "Load Indira AC1";
   } else if (selectedDevice === "35") {
    selectedDevicename = "Load Indira Light1 + common area";
   } else if (selectedDevice === "45") {
    selectedDevicename = "Load Indira AC2";
   } else if (selectedDevice === "46") {
    selectedDevicename = "Load Indira Light2 + common area";
   } else if (selectedDevice === "47") {
    selectedDevicename = "Load Radhikabai AC4";
   } else if (selectedDevice === "48") {
    selectedDevicename = "Load Radhikabai Indus Tower";
   } else if (selectedDevice === "49") {
    selectedDevicename = "Load Radhikabai AC3";
   } else if (selectedDevice === "50") {
    selectedDevicename = "Load Indira RO Water Plant";
   }
  

  
if (selectedHost === "AV7") {
  selectedHostname = "Main Panel room";
} else if (selectedHost === "AV6") {
  selectedHostname = "CVTS building";
} else if (selectedHost === "AV8") {
  selectedHostname = "Yashoda hostel panel";
} else if (selectedHost === "AV1") {
  selectedHostname = "OT store";
} else if (selectedHost === "AV2") {
  selectedHostname = "SPDC Vodafone tower";
} else if (selectedHost === "AV4") {
  selectedHostname = "Central Kitchen";
} else if (selectedHost === "AV5") {
  selectedHostname = "Raghobaji hostel";
} else if (selectedHost === "AV9") {
  selectedHostname = "NSB building";
} else if (selectedHost === "AV10") {
  selectedHostname = "AVBRH electrical room";
} else if (selectedHost === "AV11") {
  selectedHostname = "750 KVA Incomer (DMIMS) panel room";
} else if (selectedHost === "AV12") {
  selectedHostname = "Saraswati hostel";
} else if (selectedHost === "AV15") {
  selectedHostname = "500KVA Incomer panel room";
} else if (selectedHost === "AV17") {
  selectedHostname = "Guest house feeder panel";
} else if (selectedHost === "AV16") {
  selectedHostname = "CHILLER ROOM";
} else if (selectedHost === "AV18") {
  selectedHostname = "Cancer Hospital GF panel room";
} else if (selectedHost === "JBM") {
  selectedHostname = "Meghdootam apartment";
} else if (selectedHost === "JB1") {
  selectedHostname = "University building panel room";
} else if (selectedHost === "JB2") {
  selectedHostname = "Ganesh";
} else if (selectedHost === "JB3") {
  selectedHostname = "Vivekanand";
} else if (selectedHost === "JB4") {
  selectedHostname = "Paramhans";
} else if (selectedHost === "JB5") {
  selectedHostname = "Sai";
} else if (selectedHost === "JB6") {
  selectedHostname = "Shivaji";
} else if (selectedHost === "JB8") {
  selectedHostname = "Saraswati hostel";
} else if (selectedHost === "J4") {
  selectedHostname = "Shalinitai";
} else if (selectedHost === "J5") {
  selectedHostname = "Gayatri";
} else if (selectedHost === "J6") {
  selectedHostname = "sharda";
} else if (selectedHost === "J7") {
  selectedHostname = "Durga";
} else if (selectedHost === "J8") {
  selectedHostname = "Radhikabai & Indira";
} else if (selectedHost === "J9") {
  selectedHostname = "Vaishnavi";
} else if (selectedHost === "J10") {
  selectedHostname = "Jijau";
} else {
  selectedHostname = "defaultHostname";
}
  

  const onHostChange = (event) => {
    const host = event.target.value;
    setSelectedHost(host);

    // Update the device options based on the selected host
    if (host === 'J9') {
      setSelectedDevice('');
    } else if (host === 'J10') {
      setSelectedDevice('');
    } else if (host === 'J4') {
      setSelectedDevice('');
    } else if (host === 'J5') {
      setSelectedDevice('');
    } else if (host === 'J6') {
      setSelectedDevice('');
    } else if (host === 'J7') {
      setSelectedDevice('');
    } else if (host === 'J8') {
      setSelectedDevice('');
    } else if (host === 'AV11') {
      setSelectedDevice('');
    } else if (host === 'JB8') {
      setSelectedDevice('');
    } else if (host === 'AV7') {
      setSelectedDevice('');
    } else if (host === 'JB1') {
      setSelectedDevice('');
    } else if (host === 'JB2') {
      setSelectedDevice('');
    } else if (host === 'JB3') {
      setSelectedDevice('');
    } else if (host === 'JB4') {
      setSelectedDevice('');
    } else if (host === 'JB5') {
      setSelectedDevice('');
    } else if (host === 'JB6') {
      setSelectedDevice('');
    } else if (host === 'JBM') {
      setSelectedDevice('');
    } else if (host === 'AV1') {
      setSelectedDevice('');
    } else if (host === 'AV10') {
      setSelectedDevice('');
    } else if (host === 'AV15') {
      setSelectedDevice('');
    } else if (host === 'AV16') {
      setSelectedDevice('');
    } else if (host === 'AV17') {
      setSelectedDevice('');
    } else if (host === 'AV18') {
      setSelectedDevice('');
    } else if (host === 'AV2') {
      setSelectedDevice('');
    } else if (host === 'AV3') {
      setSelectedDevice('');
    } else if (host === 'AV4') {
      setSelectedDevice('');
    } else if (host === 'AV5') {
      setSelectedDevice('');
    } else if (host === 'AV6') {
      setSelectedDevice('');
    } else if (host === 'AV8') {
      setSelectedDevice('');
    } else if (host === 'AV9') {
      setSelectedDevice('');
    } else {
      setSelectedDevice('23');
    }
  };

  const onDeviceChange = (event) => {
    const deviceName = event.target.options[event.target.selectedIndex].text;

    setSelectedDevice(event.target.value);
    
    setSelectedDeviceName(deviceName);
  };
  console.log("SelectedDeviceName2",SelectedDeviceName2)
  
  // https://newrcplasto.hetadatain.com/api/jnmc_graph?host=${selectedHost}&device_id=${selectedDevice}&date=${selectedDate}
  // http://127.0.0.1:8001/api/csv-data/${selectedHost}/${selectedDate}/${selectedDevice}

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true); // Set loading status to true

      try {
        const response = await fetch(`https://wardha.hetadatain.com/api/jnmc_report?host=${selectedHost}&device_id=${selectedDevice}&date=${selectedDate}&hostname=${selectedHostname}&devicename=${SelectedDeviceName2}`);
        const data = await response.json();
        console.log(data);
        setChartData(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false); // Set loading status to false
      }
    };

    fetchData();
  }, [selectedHost, selectedDevice, selectedDate, SelectedDeviceName2]);

    // Access the first row's second_diff_value and last_diff_value
    const firstRow = chartData.length > 0 ? chartData[0] : null;
  const lastRow = chartData.length > 0 ? chartData[chartData.length - 1] : null;
  const firstSecondDiffValue = firstRow ? firstRow.first_wh_R : null;
  const lastLastDiffValue = lastRow ? lastRow.last_wh_R : null;
  


  // const handleClick3 = () => {
  //   const previousURL = window.location.href; // Get the current URL

  //   window.location.href = 'https://newrcplasto.hetadatain.com/api/jnmc_graph?host=AV11&device_id=49&date=2023-05-22'; // Open the new link

  //   setTimeout(() => {
  //     window.location.href = 'http://localhost:3000/'; // Go back to the previous link
  //   }, 1000); // Adjust the delay time as needed
  // };




  useEffect(() => {
    // Create chart instance
    const chart = am4core.create("chartdiv", am4charts.XYChart);

    // Convert date strings to Date objects and update the dt_time field to hh:mm format
    const chartDataWithTime = chartData.map((dataPoint) => ({
      ...dataPoint,
      dt_time: new Date(dataPoint.dt_time).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    }));

    // Add data to chart
    chart.data = chartDataWithTime;

    // Create X axis
    const categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "dt_time";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.labels.template.rotation = -90;
    categoryAxis.renderer.labels.template.horizontalCenter = "left";
    categoryAxis.renderer.labels.template.verticalCenter = "middle";

    // Create Y axis for "value" column
    const valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.minWidth = 50;
    valueAxis.title.text = "";
    valueAxis.renderer.grid.template.location = 0;

    // Create Y axis for "value1" column
    const valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis2.renderer.minWidth = 50;
    valueAxis2.title.text = "";
    valueAxis2.renderer.grid.template.location = 0;
    valueAxis2.renderer.opposite = true;

    // Create series for "value" column
    const series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "value";
    series.dataFields.categoryX = "dt_time";
    series.strokeWidth = 2;
    series.minBulletDistance = 10;
    series.tooltipText = "{value}";
    series.name = "KWH_Rec";
    series.fill = am4core.color("#008FFB");
    series.stroke = am4core.color("#008FFB");

    const series1 = chart.series.push(new am4charts.ColumnSeries());
    series1.dataFields.valueY = "value1";
    series1.dataFields.categoryX = "dt_time";
    series1.strokeWidth = 2;
    series1.minBulletDistance = 10;
    series1.tooltipText = "{value1}";
    series1.name = "KWH_Del";
    series1.fill = am4core.color("#20c997");
    series1.stroke = am4core.color("#20c997");

    const series2 = chart.series.push(new am4charts.ColumnSeries());
    series2.dataFields.valueY = "value2";
    series2.dataFields.categoryX = "dt_time";
    series2.strokeWidth = 2;
    series2.minBulletDistance = 10;
    series2.tooltipText = "{value2}";
    series2.name = "WH_1";
    series2.fill = am4core.color("#ffc107");
    series2.stroke = am4core.color("#ffc107");

    const series3 = chart.series.push(new am4charts.ColumnSeries());
    series3.dataFields.valueY = "value3";
    series3.dataFields.categoryX = "dt_time";
    series3.strokeWidth = 2;
    series3.minBulletDistance = 10;
    series3.tooltipText = "{value3}";
    series3.name = "WH_2";
    series3.fill = am4core.color("#28a745");
    series3.stroke = am4core.color("#28a745");

    const series4 = chart.series.push(new am4charts.ColumnSeries());
    series4.dataFields.valueY = "value4";
    series4.dataFields.categoryX = "dt_time";
    series4.strokeWidth = 2;
    series4.minBulletDistance = 10;
    series4.tooltipText = "{value4}";
    series4.name = "WH_3";
    series4.fill = am4core.color("#dc3545");
    series4.stroke = am4core.color("#dc3545");

    // Add legend
    chart.legend = new am4charts.Legend();
    chart.legend.useDefaultMarker = true;
    chart.legend.position = "bottom";
    
    

    // Add title
    const title = chart.titles.create();
    title.text = `Hourly Graph`;
    title.fontSize = 20;
    title.marginBottom = 20;
    

    // Add chart cursor
    chart.cursor = new am4charts.XYCursor();
  }, [chartData]);

  const handleHostChange = (event) => {
    setSelectedHost(event.target.value);
  };

  const handleDeviceChange = (event) => {
    setSelectedDevice(event.target.value);
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };
 
 
  const generateReportUrl = () => {
    const url = `https://wardha.hetadatain.com/api/jnmc_report?host=${selectedHost}&device_id=${selectedDevice}&date=${selectedDate}&hostname=${selectedHostname}&devicename=${SelectedDeviceName2}`;
    return url;
  };


  useEffect(() => {
    const url = generateReportUrl();
    setReportUrl(url);
  }, [selectedHost, selectedDevice, selectedDate, selectedHostname,SelectedDeviceName2]);
  

  return (
    <div>
      <div style={{ display: "flex", marginBottom: "10px" }}>
      {/* <h2>First Row Values</h2> */}
      {/* {firstRow ? (
        <div>
          <h3>Start Reading: {firstSecondDiffValue}</h3>
        </div>
      ) : (
        <p>No data available</p>
      )}
      {lastRow ? (
        <div>
          <h3>End Reading: {lastLastDiffValue}</h3>
        </div>
      ) : (
        <p>No data available</p>
      )} */}
      <div style={{ marginBottom: "10px", display: "flex", alignItems: "center" , marginRight: "10px" }}>
    
      <label htmlFor="select_host" style={{ marginRight: "10px", fontWeight: "bold" }}>Select Host:</label>
      <select id="select_host" value={selectedHost} onChange={onHostChange}style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
      minWidth: "200px", // Adjust the width as needed
    }}>
      <option value="">Select Host</option>
    <option value="AV10">AVBRH Electrical Room</option>
      <option value="AV18">Cancer Hospital GF Panel Room</option>
      <option value="AV4">Central Kitchen</option>
      <option value="AV16">Chiller Room</option>
      <option value="AV6">CVTS Building</option>

      <option value="J7">Durga</option>
      <option value="JB2">Ganesh</option>
      <option value="AV17">Guest House Feeder Panel</option>
      <option value="J5">Gayatri</option>

      <option value="J10">Jijau</option>
      <option value="AV7">Main Panel Room(Boy Hostel)</option>   
      <option value="J4">Main Incomer Panel Health Club (Shalinata)</option>
      <option value="AV15">Main Incomer Panel AVBRH(500KVA Incomer Panel Room)</option>      
      <option value="AV11">Main Incomer Panel JNMC(750 KVA Incomer (JNMC) panel room)</option>
      <option value="JBM">Meghdoot apartment</option>

      <option value="AV9">NSB Building</option>
      <option value="AV3">Ortho Panel</option>
      <option value="AV1">OT store</option>


      <option value="JB4">Paramhans</option>
      <option value="J8">Radhikabai & Indira</option>
      <option value="AV5">Raghobaji Hostel</option>

      <option value="JB5">Sai</option>
      <option value="AV12">Saraswati hostel</option>
      <option value="JB8">Saraswati hostel</option>      
      <option value="J6">sharda</option>
      <option value="JB6">Shivaji</option>
      <option value="AV2">SPDC Vodafone Tower</option> 

      <option value="JB1">University Building Panel Room</option>
      <option value="J9">Vaishnavi</option>
      <option value="JB3">Vivekanand</option>
      <option value="AV8">Yashoda Hostel Panel</option>  
        
  </select>
      </div>
      <div style={{marginBottom: "10px", display: "flex", alignItems: "center" , marginRight: "10px" }}>
      <label htmlFor="select_device" style={{ marginRight: "10px", fontWeight: "bold" }}>Select Device:</label>
      <select id="select_device" value={selectedDevice} onChange={onDeviceChange} style={{
      padding: "5px",
      borderRadius: "5px",
      border: "1px solid #ccc",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      outline: "none",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
      minWidth: "200px", // Adjust the width as needed
    }}>
      {selectedHost === 'AV11' ? (
          <>
            <option value="">Select</option>
            <option value="31">Auditorium</option>
            <option value="42">Food Court Feeder</option>
            <option value="40">JNMC Dean Office Feeder</option>
            <option value="33">JNMC Lecture Feeder</option>   
            <option value="50">JNMC Solar</option> 
            <option value="49">MET HALL Feeder</option>
            <option value="27">Museum Ac</option>
            <option value="44">Saraswati Hostel</option>
            <option value="29">SPDC+Nursing+University Feeder</option>     
            <option value="43">SPDC</option> 
            <option value="41">STP PLANT (DMIHER)</option>                          
            <option value="23">750KVA JNMC LT Incomer</option>
            <option value="57">315 KVA Transformer JNMC</option>

            
            
            

          </>
           ) : selectedHost === 'JB8' ? (
            <>
              <option value="">Select</option>
              <option value="45">FF Mess Saraswati</option>
              <option value="46">GF Mess Saraswati</option>
              
            </>
        ) : selectedHost === 'AV16' ? (
          <>
            <option value="">Select</option>
            <option value="60">Main HVAC P1</option>
            <option value="61">Main HVAC P2</option>
            <option value="62">NSB Solar</option>
            <option value="63">Secondary Pump</option>
          </>
          ) : selectedHost === 'J8' ? (
            <>
            <option value="">Select</option>
            <option value="62">Indira Hostel Main</option>
            <option value="61">Radhikabai Hostel Main</option>      
            <option value="31">Load Radhikabai AC1</option>
            <option value="32">Load Radhikabai Light + common area</option>
            <option value="33">Load Radhikabai AC2</option>
            <option value="34">Load Indira AC1</option>
            <option value="35">Load Indira Light1 + common area</option>
            <option value="45">Load Indira AC2</option>
            <option value="46">Load Indira Light2 + common area</option>
            <option value="47">Load Radhikabai AC4</option>
            <option value="48">Load Radhikabai Indus Tower</option>
            <option value="49">Load Radhikabai AC3</option>
            <option value="50">Load Indira RO Water Plant</option>
            <option value="21">Solar Indira</option>
            <option value="20">Solar Radhikabai</option>
            
            

            </>
          ) : selectedHost === 'J7' ? (
            <>
              <option value="">Select</option>              
              <option value="59">Durga Borewell</option>
            </>
          ) : selectedHost === 'J6' ? (
            <>
              <option value="">Select</option>
              <option value="22">Load Sharda Light + common area</option>
              <option value="24">Load Sharda AC</option>
              <option value="16">Solar Sharda</option>
              <option value="64">Sharda Hostel Main</option>
            </>
           ) : selectedHost === 'J5' ? (
            <>
              <option value="">Select</option>
              <option value="60">Gayatri Hostel Main </option>
              <option value="25">Load Gayatri AC1</option>
             
            </>
           ) : selectedHost === 'J4' ? (
            <>
              <option value="">Select</option>
              <option value="65">Gym</option>
              <option value="3">Hostel Sharda Light</option>
              <option value="4">Hostel Durga</option>
              <option value="5">Hostel  Sharda AC</option>
              <option value="7">Health Club</option>              
              <option value="9">Hostel Radhikabai</option>
              <option value="10">Hostel Indira</option>
              <option value="11">Hostel Shalinata</option>
              <option value="8">Load Reception</option>
              <option value="36">Load Shalinata AC1</option>
              <option value="37">Load Shalinata Light1 + common area</option>
              <option value="38">Load Shalinata Light2 + common area</option>
              <option value="39">Load Shalinata AC2</option>
              <option value="40">Load Shalinata AC3</option>
              <option value="41">Load Shalinata Light3 + common area</option>
              <option value="42">Load Shalinata AC4</option>
              <option value="43">Load Shalinata Light4 + common area</option>
              <option value="6">PG Guest House & Banglow</option>
              <option value="66">VIP Guest House</option>
              <option value="1">800 KVA Health Club Incomer</option>
              <option value="2">750 KVA Health Club Incomer</option>
              

              
            </>
           ) : selectedHost === 'J9' ? (
            <>
            
              <option value="">Select</option>
              <option value="12">Hostel Gayatri</option>
              <option value="13">Hostel Vaishnavi</option>
              <option value="51">Meghe Height Common Area1</option>
              <option value="52">Meghe Height Common Area2</option>
              <option value="54">Meghe Height Building 1</option>
              <option value="55">Meghe Height Building 2</option>
              <option value="56">Meghe Height Building 3</option>
              <option value="57">Meghe Height Building 4</option>
              <option value="14">Meghe Height</option>            
              <option value="18">Solar Vaishnavi</option>
              
              
            </>
            ) : selectedHost === 'J10' ? (
              <>
               <option value="">Select</option>
               <option value="15">Hostel Jijau</option>
                <option value="58">Jijau AC2</option>
                <option value="63">Jijau Hostel Main</option>
                <option value="29">Load Jijau AC</option>
                <option value="30">Load Jijau Light + common area</option>
                
               
                
                
              </>
        ) : selectedHost === 'AV7' ? (
          <>
            <option value="">Select</option>
            
            <option value="4">Ganesh + Shivaji</option>
            <option value="10">Sai Panel</option>
            <option value="11">STP</option>
            <option value="7">Paramhans Panel</option>
            <option value="8">Vivekanand AC Panel</option>
            <option value="9">Vivekanand Light Panel</option>          
            <option value="1">315 Incomer (Boys hostel Feeder)</option>
            <option value="2">200 Incomer</option>
          </>
          ) : selectedHost === 'JB1' ? (
            <>
              <option value="">Select</option>
              <option value="54">Nursing Main</option>
              <option value="53">Solar Nursing</option>
              <option value="56">Solar University</option>                       
              <option value="55">University Main</option>
              </>
          ) : selectedHost === 'JB2' ? (
            <>
              <option value="">Select</option>
              <option value="5">Ganesh</option>
              <option value="20">Solar Ganesh</option>
              <option value="21">Load Ganesh AC</option>
              <option value="22">Load Ganesh Light + common area</option>
            </>
            ) : selectedHost === 'JB3' ? (
              <>
                <option value="">Select</option>
                <option value="18">Solar Vivekanand</option>
                <option value="30">Load Vivekanand AC</option>
                <option value="32">Load Vivekanand Airtel</option>
                <option value="34">Load Vivekanand Light + Airtel + common area</option>
              </>
              ) : selectedHost === 'JB4' ? (
                <>
                  <option value="">Select</option>
                  <option value="51">Paramhans Hostel Main</option>
                  <option value="17">Solar Paramhans</option>                
                 
                </>
                ) : selectedHost === 'JB5' ? (
                  <>
                    <option value="">Select</option>
                    <option value="19">Solar Sai</option>
                    <option value="35">Load Sai Light + common area</option>
                    <option value="36">Load Sai Mess</option>
                  </>
                  ) : selectedHost === 'JB6' ? (
                    <>
                      <option value="">Select</option>
                      <option value="6">Shivaji</option>
                      <option value="16">Solar Shivaji</option>
                      <option value="24">Load Ganesh Mess</option>
                      <option value="25">Load Shivaji AC</option>
                      <option value="26">Load Shivaji Light + common area</option>
                    </>
                    ) : selectedHost === 'JBM' ? (
                      <>
                        <option value="">Select</option>                        
                        <option value="12">Meghdhoot Block 1</option>
                        <option value="13">Meghdhoot Block 2</option>
                        <option value="14">Meghdhoot Block 3</option>
                        <option value="15">Meghdhoot Block 4 & 5</option>
                        <option value="39">Meghdhoot Pump</option>
                        <option value="37">Load Meghdhoot Block 4</option>
                        <option value="38">Load Meghdhoot Block 5</option>
                        <option value="3">315 Incomer Meghdoot</option>
                        
                      </>
                      ) : selectedHost === 'AV1' ? (
                        <>``
                          <option value="">Select</option>
                          <option value="23">Cotex Pharmacy OT Store FF A Block AVBRH</option>
                        </>
                        ) : selectedHost === 'AV10' ? (
                          <>
                            <option value="">Select</option>
                            <option value="2">A Block & C Block Solar AVBRH</option>
                            <option value="22">Cotex Pharmacy Store GF A Block AVBRH</option>
                          </>
                          ) : selectedHost === 'AV15' ? (
                            <>
                            <option value="">Select</option>
                            <option value="21">A Block 270 KVA Panel Room</option>         
                            <option value="57">Cancer Hospital</option>
                            <option value="19">Cathlab Feeder</option>
                            <option value="55">Critical</option>
                            <option value="20">CT Scan Feeder</option>
                            <option value="7">Fire Pump Feeder</option>
                            <option value="6">Guest House Panel Feeder</option>   
                            <option value="54">NON critical</option>                         
                            <option value="5">Ortho Panel Feeder</option>
                            <option value="8">RNPC Feeder</option>
                            <option value="9">TUCB ATM from 500 kVA TR</option>
                            <option value="4">Yashoda Feeder</option>
                            <option value="3">500 kVA AVBRH LT</option>
                            <option value="18">750 kVA AVBRH LT -Incomer</option>                                                                           
                            <option value="56">800 kVA T1</option> 
                            <option value="53">800 KVA T2</option>
                            </>
                            ) : selectedHost === 'AV16' ? (
                              <>
                                <option value="">Select</option>
                                <option value="60">Main HVAC P1</option>
                                <option value="61">Main HVAC P2</option>
                                <option value="62">NSB Solar</option>
                                <option value="63">Secondary Pump</option>
                              </>
                              ) : selectedHost === 'AV17' ? (
                                <>
                                  <option value="">Select</option>
                                  <option value="42">BSNL Tower</option>
                                  <option value="14">Doctor Qtrs1 (Mahajan Building)</option>
                                  <option value="15">Doctor Qtrs2 (Sune Building)</option>
                                  <option value="16">Guest House Load</option>
                                  <option value="13">Laundry</option>                                  
                                 
                                  
                                </>
                                ) : selectedHost === 'AV18' ? (
                                  <>
                                    <option value="">Select</option>
                                    <option value="68">AHU Basement</option>
                                    <option value="69">AHU Basement(LINAC M/C)</option>
                                    <option value="70">AHU GF Panel</option>
                                    <option value="71">AHU TF</option>
                                    <option value="65">Cancer Hospital Pharmacy</option>
                                    <option value="67">Solar Cancer</option>
                                    

                                  </>
                                  ) : selectedHost === 'AV2' ? (
                                    <>
                                      <option value="">Select</option>
                                      <option value="1">Vodafone Tower</option>
                                    </>
                                      ) : selectedHost === 'AV3' ? (
                                        <>
                                          <option value="">Select</option>
                                          <option value="73">Ortho Panel Room</option>
                                          <option value="72">Solar Ortho</option>                                          
                                          <option value="11">SODAXSO</option>
                                        </>
                                    ) : selectedHost === 'AV4' ? (
                                      <>
                                        <option value="">Select</option>
                                  <option value="17">Central Kitchen</option>
                                  <option value="50">MRI</option>
                                  <option value="51">Oxygen Plant 1</option>
                                  <option value="52">Oxygen Plant 2</option>
                                  <option value="58">Road Side Pharmacy</option>
                                      </>
                                      ) : selectedHost === 'AV5' ? (
                                        <>
                                          <option value="">Select</option>
                                        <option value="47">Raghobaji AC</option>
                                        <option value="43">Raghobaji Main</option>                                        
                                        <option value="48">Raghobaji Light</option>
                                        </>
                                        ) : selectedHost === 'AV6' ? (
                                          <>
                                            <option value="">Select</option>
                                      <option value="24">Mai Optical</option>
                                      <option value="25">PNB ATM</option>
                                          </>
                                          ) : selectedHost === 'AV8' ? (
                                            <>
                                              <option value="">Select</option>
                                        <option value="46">Cotex Pharmacy Store</option>
                                        <option value="66">WHC Store (Yashoda)</option>
                                        <option value="10">Yashoda Solar</option>                                        
                                        <option value="12">Yashoda Hostel Main</option>
                                        <option value="44">Yashoda AC1</option>
                                        <option value="45">Yashoda AC2</option>
                                        
                                            </>
                                            ) : selectedHost === 'AV9' ? (
                                              <>
                                                <option value="">Select</option>
                                          <option value="41">Cotex Pharmacy Store GF NSB AVBRH</option>
                                          <option value="59">Cotex Pharmacy NSB (2F)</option>                                                                        
                                          <option value="74">NSB OT Pharmacy 2F</option>
                                          <option value="40">TUCB ATM (NSB)</option>
                                          
                                          
                                              </>
        ) : (
          
          <option value="">Select Device</option>
        )}
      </select>
</div>
      <div style={{ marginBottom: "10px", display: "flex", alignItems: "center", marginRight: "10px"  }}>
        <label htmlFor="datePicker" style={{ marginRight: "10px", fontWeight: "bold" }}>Select Date:</label>
        <input
          type="date"
          id="datePicker"
          value={selectedDate}
          onChange={handleDateChange} style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            outline: "none",
            fontFamily: "Arial, sans-serif",
            fontSize: "14px",
            minWidth: "200px", // Adjust the width as needed
          }}
        />
      </div>
      </div>
      <div>
      {isLoading ? (
        <div className="loading-container">
          <div className="spinner"></div>
        </div>
      ) : (
        <>
          {reportUrl && (
        <>
          <iframe src={reportUrl} style={{ width: "96%", height: "550px" }} title="Report" />

        </>
      )}
        </>
      )}
    </div>
        </div>
  );
};

export default Report_wardha;