import React from 'react';
import './too_bar.css';
import Login from './Login';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { fetchData, logout } from './api';

function Top_Bar() {
  const handleLogout = () => {
    // Perform any logout logic if necessary

    // Redirect to Login component
    window.location.href = 'https://wardha.hetadatain.com';
  };

  return (
    <div className="container">
      <img src="log.png" alt="Logo Left" className="logoLeft" />
      <h1 className="title">Energy Monitoring System for Sawangi Campus</h1>
      <div className="logoutContainer" onClick={handleLogout}>
        <FontAwesomeIcon icon={faSignOutAlt} className="logoutIcon" />
        <p className="logouttext">Log Out</p>
      </div>
      <img src="down.png" alt="Logo Right" className="logoRight" />
    </div>
  );
}

export default Top_Bar;
