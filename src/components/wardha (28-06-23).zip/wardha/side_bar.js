import React, { useState, useEffect } from "react";
import Bar_graph from "./bar_graph";
import { FaChartBar, FaFileCsv, FaFileAlt, FaSun } from 'react-icons/fa';
import Report_wardha from "./report_wardha";
import './side_bar.css';
import LineChart_csv from './GraphComponent2'
import BoxWithButton from './BoxWithButton';

const Sidebar_wardha = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("");

  useEffect(() => {
    // Simulate a loading delay
    setTimeout(() => {
      setIsLoading(false);
    }, 2000); // Set the duration of the loading delay in milliseconds
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case "graph":
        return <Bar_graph />;
      case "graph_csv":
        return <LineChart_csv />;
      case "report_wardha":
        return <Report_wardha />;
      case "solar":
        return <BoxWithButton />;
      default:
        return null;
    }
  };

  return (
    <div className="sidebar">
      <div className="icons-container">
        <div
          className={`icon-container ${activeTab === "graph" ? "active" : ""}`}
          onClick={() => setActiveTab("graph")}
        >
          <FaChartBar size={24} />
        </div>
        <div
          className={`icon-container ${activeTab === "graph_csv" ? "active" : ""}`}
          onClick={() => setActiveTab("graph_csv")}
        >
          <FaFileCsv size={24} />
        </div>
        <div
          className={`icon-container ${activeTab === "report_wardha" ? "active" : ""}`}
          onClick={() => setActiveTab("report_wardha")}
        >
          <FaFileAlt size={24} />
        </div>
        <div
          className={`icon-container ${activeTab === "solar" ? "active" : ""}`}
          onClick={() => setActiveTab("solar")}
        >
          <FaSun size={24} />
        </div>
      </div>

      <div className="content">
        {isLoading ? (
          <div className="loading-bar">
            <div className="spinner"></div>
            Loading...
          </div>
        ) : (
          renderContent()
        )}
      </div>
    </div>
  );
};

export default Sidebar_wardha;
